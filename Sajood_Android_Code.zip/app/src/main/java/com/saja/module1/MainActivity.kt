package com.saja.module1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { ModuleScreens() } } }
}

@Composable fun ModuleScreens() {
 var screen by remember { mutableStateOf("Birthday Card") }
 var dark by remember { mutableStateOf(false) }
 val bg = if(dark) Color(0xFF171717) else Color(0xFFFFF5ED)
 val fg = if(dark) Color(0xFFFFE0D2) else Color(0xFF201713)
 Surface(Modifier.fillMaxSize(), color=bg, contentColor=fg) {
  Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment=Alignment.CenterHorizontally) {
   Row(verticalAlignment=Alignment.CenterVertically) {
    Text("Sajood Abu Zeid", fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
    TextButton(onClick={dark=!dark}) { Text(if(dark) "Light" else "Dark") }
   }
   Spacer(Modifier.height(8.dp))
   Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
    listOf("Birthday Card","Task Done","Quadrant","Article","Business Card").forEach { name ->
     TextButton(onClick={screen=name}) { Text(name, fontSize=10.sp) }
    }
   }
   Spacer(Modifier.height(12.dp))
   Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
    when(screen) {
     "Birthday Card" -> Birthday(bg,fg)
     "Task Done" -> TaskDone(fg)
     "Quadrant" -> Quadrant(fg)
     "Article" -> Article(fg)
     else -> BusinessCard(fg)
    }
   }
  }
 }
}
@Composable fun Birthday(bg:Color, fg:Color) {
 Column(Modifier.fillMaxWidth().background(Color(0xFFD8E8D7), RoundedCornerShape(22.dp)).padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
  Text("✦  ✧  ✦",fontSize=44.sp,color=Color(0xFF8B75D8))
  Text("Happy",fontSize=48.sp,color=Color(0xFF211610),textAlign=TextAlign.Center)
  Text("Birthday",fontSize=48.sp,color=Color(0xFF211610),textAlign=TextAlign.Center)
  Text("Sajood!",fontSize=48.sp,color=Color(0xFF211610),textAlign=TextAlign.Center)
  Spacer(Modifier.height(18.dp)); Text("From Emma",fontSize=26.sp,color=Color.Red)
 }
}
@Composable fun TaskDone(fg:Color) {
 Column(horizontalAlignment=Alignment.CenterHorizontally) {
  Box(Modifier.size(220.dp).background(Color(0xFF38D987),RoundedCornerShape(120.dp)),contentAlignment=Alignment.Center) { Text("✓",fontSize=120.sp,color=Color(0xFF4385F5)) }
  Spacer(Modifier.height(28.dp)); Text("All tasks completed",fontSize=24.sp,fontWeight=FontWeight.Bold,color=fg)
  Spacer(Modifier.height(12.dp)); Text("Nice work!",fontSize=22.sp,color=fg)
 }
}
@Composable fun Quadrant(fg:Color) {
 Column(Modifier.fillMaxSize()) {
  Row(Modifier.weight(1f)) { QCell("Text composable","Displays text and follows recommended Material Design guidelines.",Color(0xFFFFDCC5),fg); QCell("Image composable","Creates a composable that lays out and draws an image.",Color(0xFFFFE9DE),fg) }
  Row(Modifier.weight(1f)) { QCell("Row composable","Places its children in a horizontal sequence.",Color(0xFFFFE9DE),fg); QCell("Column composable","Places its children in a vertical sequence.",Color(0xFFFFDCC5),fg) }
 }
}
@Composable fun QCell(title:String,body:String,color:Color,fg:Color) {
 Column(Modifier.weight(1f).fillMaxHeight().background(color).padding(18.dp),verticalArrangement=Arrangement.Center) { Text(title,fontWeight=FontWeight.Bold,fontSize=18.sp,color=fg); Spacer(Modifier.height(16.dp)); Text(body,fontSize=16.sp,color=fg,lineHeight=24.sp) }
}
@Composable fun Article(fg:Color) {
 Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.Top) {
  Box(Modifier.fillMaxWidth().height(140.dp).background(Color(0xFF00475B)),contentAlignment=Alignment.Center) { Text("▣  ⚙  ✎  Android",fontSize=34.sp,color=Color(0xFFBCEBFF)) }
  Spacer(Modifier.height(24.dp)); Text("Jetpack Compose tutorial",fontSize=30.sp,color=fg)
  Spacer(Modifier.height(18.dp)); Text("Jetpack Compose is a modern toolkit for building native Android UI. Compose simplifies and accelerates UI development on Android with less code, powerful tools, and intuitive Kotlin APIs.",fontSize=18.sp,color=fg,lineHeight=29.sp)
  Spacer(Modifier.height(18.dp)); Text("In this tutorial, you build a simple UI component with declarative functions. Compose functions describe what elements you want and the compiler does the rest.",fontSize=18.sp,color=fg,lineHeight=29.sp)
 }
}
@Composable fun BusinessCard(fg:Color) {
 Column(Modifier.fillMaxWidth().background(Color(0xFFDAF1E8),RoundedCornerShape(24.dp)).padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally) {
  Box(Modifier.size(110.dp).background(Color(0xFF167C67),RoundedCornerShape(60.dp)),contentAlignment=Alignment.Center) { Text("S",fontSize=56.sp,color=Color.White,fontWeight=FontWeight.Bold) }
  Spacer(Modifier.height(20.dp)); Text("Sajood Abu Zeid",fontSize=30.sp,fontWeight=FontWeight.Bold,color=fg)
  Text("Android Developer",fontSize=20.sp,color=Color(0xFF167C67))
  Spacer(Modifier.height(22.dp)); Text("✉  sajaabozaid301@gmail.com",fontSize=16.sp,color=fg,textAlign=TextAlign.Center)
 }
}
